# CBA Suite v0.1

Sistema de control de cuarteles para el Cuerpo de Bomberos de Algarrobo.

## Archivos principales

- `panel.html`: panel de cada cuartel. Usar con `panel.html?cuartel=1`, `panel.html?cuartel=2`, `panel.html?cuartel=3` o `panel.html?cuartel=general`.
- `central.html`: vista de Central.
- `admin.html`: reservado para próxima etapa.

## Configuración obligatoria

Editar `js/config.js` y reemplazar:

```js
API_URL: "PEGA_AQUI_TU_URL_DE_APPS_SCRIPT"
```

por la URL de la implementación web de Apps Script.

## Fotos

Subir las fotos en la carpeta `img` con el número de registro:

```text
5047.jpg
5088.jpg
```

Si no existe la foto, se usa `img/sinfoto.jpg`.
